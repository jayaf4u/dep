from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from datetime import datetime
import csv

app = Flask(__name__)

# Define the survey questions and response options
questions = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself or that you are a failure or have let yourself or your family down?",
    "Trouble concentrating on things, such as reading the newspaper or watching television?",
    "Moving or speaking so slowly that other people could have noticed?",
    "Thoughts that you would be better off dead or of hurting yourself in some way?"
]
response_options = ["Not at all", "Several days", "More than half the days", "Nearly every day"]

# Load the depression dataset
depression_data = pd.read_csv("depression_dataset.csv")

# Train a random forest classifier on the depression dataset
X_train = depression_data.drop("Depressed", axis=1)
y_train = depression_data["Depressed"]
rf_model = RandomForestClassifier(n_estimators=10, random_state=2)
rf_model.fit(X_train, y_train)

# Define the name and location of the output CSV file
output_file = "survey_responses.csv"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    # Collect responses from the user
    responses = []
    for i, question in enumerate(questions):
        response = request.form.get(f"question_{i}")
        if response:
            responses.append(response_options.index(response))
        else:
            # If the user didn't answer the question, use the default value from the training dataset
            responses.append(X_train.mean()[i])
    
    # Make a prediction based on the user's responses
    prediction = rf_model.predict([responses])[0]
    if prediction == 0:
        prediction_text = "not depressed"
    else:
        prediction_text = "depressed"
    
    # Write the user's responses to the CSV file
    with open(output_file, mode="a", newline="") as csv_file:
        writer = csv.writer(csv_file)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow([timestamp] + responses)
    
    # Render the prediction page with the prediction result
    return render_template("prediction.html", prediction=prediction_text)

if __name__ == "__main__":
    app.run(debug=True)
